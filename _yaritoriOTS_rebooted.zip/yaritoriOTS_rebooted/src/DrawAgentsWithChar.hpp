//
//  DrawAgentsWithChar.hpp
//  yaritori
//
//  Created by sonir on 1/13/18.
//
//

#ifndef DrawAgentsWithChar_hpp
#define DrawAgentsWithChar_hpp

#include <stdio.h>
#include "ofMain.h"
#include "ofxGismo.h"

class DrawAgentsWithChar {
    
    public:
        void draw(GismoManager *gismo, float screen_w, float screen_h);

    
};

#endif /* DrawAgentsWithChar_hpp */
