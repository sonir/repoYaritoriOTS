# repoYaritoriOTS

How to Use
1. extract "_yaritoriOTSProjectTemplate.zip" on your favorite place.
2. change this folder name from repoYaritoriOTS to src
3. overwrite the src folder in the cextracted project with this new src folder.
