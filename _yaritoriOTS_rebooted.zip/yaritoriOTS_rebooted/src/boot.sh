PATH="$PATH":~/.nodebrew/current/bin:/usr/bin
#source ~/.bashrc;
killall node;
osc-hub -h 160.16.146.38 -p 52885 -s 8001 -r 57140 &

