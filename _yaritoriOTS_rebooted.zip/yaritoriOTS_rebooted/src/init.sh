echo "# repoYaritoriOTS" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/sonir/repoYaritoriOTS.git
git push -u origin master
