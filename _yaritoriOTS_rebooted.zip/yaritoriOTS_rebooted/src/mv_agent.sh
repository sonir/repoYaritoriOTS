echo "$1 was copied on /data folder."
ls
cp $1 ../../../data
